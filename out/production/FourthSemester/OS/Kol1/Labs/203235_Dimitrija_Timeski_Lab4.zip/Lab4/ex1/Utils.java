package OS.Kol1.Labs.Lab4.ex1;
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
//DIMITRIJA TIMESKI 203235
public class Utils {

    public static String LOGIN = "login:203235";
    public static String HELLO = "hello:203235";
    public static String SERVER_ANSWER = "Server says: Succesfully logged on to server!";
    public static String SERVER_WELCOME = "Server says: Server: Hello! You can start chatting with your colleagues now!";
    public static String SEND_TO = "203235:";
}
